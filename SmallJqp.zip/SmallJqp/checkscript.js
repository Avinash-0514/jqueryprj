$('#selectall').click(function() {
    var isChecked = $(this).prop('checked');
    $('input[name="check"]').prop('checked', isChecked);
  });

  $('input[name ="check"]').click(function(){
var allboxes =  $('input[name ="check"]') , selectallcheck = $('#selectall') ;
 if (allboxes.length === allboxes.filter(':checked').length)
 {
selectallcheck.prop('checked',true);
 }
else{
    selectallcheck.prop('checked',false);
}
  });
